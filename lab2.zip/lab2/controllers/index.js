var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'lab2 - my family' });
});

router.get('/tyler', (req, res, next) => {
  res.render('tyler', { title: 'Tyler' })
})

router.get('/kim', (req, res, next) => {
  res.render('kim', { title: 'Kim' })
})

router.get('/chris', (req, res, next) => {
  res.render('chris', { title: 'Chris' })
})

router.get('/kyle', (req, res, next) => {
  res.render('kyle', { title: 'Kyle' })
})

router.get('/megan', (req, res, next) => {
  res.render('megan', { title: 'Megan' })
})

router.get('/jagger', (req, res, next) => {
  res.render('jagger', { title: 'Jagger' })
})


module.exports = router;
